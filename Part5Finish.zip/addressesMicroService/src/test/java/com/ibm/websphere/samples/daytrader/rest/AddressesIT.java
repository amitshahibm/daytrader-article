//
// RestIT.java
// 
package com.ibm.websphere.samples.daytrader.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class AddressesIT {

	String addressesRoute = System.getenv("addresses_app_route"); 
	
	@Test
	public void testGetAddresses() {
		testEndpoint(addressesRoute + "/addresses", "GET");
	}

	@Test
	public void testGetAddress() {
		testEndpoint(addressesRoute + "/addresses/Entry4", "GET");
	}

	@Test
	public void testSearch() {
		testEndpoint(addressesRoute + "/addresses/search/Entry4", "GET");
	}

	private void testEndpoint(String endpoint, String httpMethod) {
		System.out.println(endpoint);
		Response response = sendRequest(endpoint, httpMethod);
		int responseCode = response.getStatus();
		assertTrue("Incorrect response code: " + responseCode, responseCode == 200);
		String responseString = response.readEntity(String.class);
		System.out.println(responseString);
		response.close();
	}

	private Response sendRequest(String url, String method) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(url);
		Invocation.Builder invoBuild = target.request();
		Response response = response = invoBuild.build(method).invoke();
		return response;
	}

} 