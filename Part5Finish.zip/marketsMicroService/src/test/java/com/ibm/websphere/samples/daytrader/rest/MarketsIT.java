
package com.ibm.websphere.samples.daytrader.rest;

import org.junit.Test;

import com.ibm.websphere.samples.daytrader.MarketSummaryDataBean;
import com.ibm.websphere.samples.daytrader.TradeAction;

public class MarketsIT {
	
	private static TradeAction tAction = new TradeAction();

   @Test
   public void testGetMarketSummary() throws Exception {
	   MarketSummaryDataBean marketSummary = tAction.getMarketSummary();
	   System.out.println("getMarketSummary() " + marketSummary.toString());
   }
    
  
}
